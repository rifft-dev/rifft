import Link from "next/link";
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  CreditCard,
  Flag,
  Sparkles,
  TimerReset,
  TrendingDown,
  TrendingUp,
  Workflow,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { getMastMeta } from "@/lib/mast";
import { getProjectBaseline, getProjectInsights, getProjectUsageSummary, getTraceComparison, getTraces } from "../lib/api";
import { redirectToBootstrap, requireCloudProject } from "../lib/require-cloud-project";

const formatSpanCount = (value: number) => new Intl.NumberFormat("en-US").format(value);
const formatPercentage = (value: number) => `${Math.round(value * 100)}%`;
const formatTokenCount = (value: number) => new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 }).format(value);
const formatSignedValue = (value: number, unit = "") => `${value > 0 ? "+" : ""}${value}${unit}`;

const formatRelative = (value: string) => {
  const now = Date.now();
  const then = new Date(value).getTime();
  const diffMs = now - then;
  const diffMinutes = Math.round(diffMs / 60000);

  if (Math.abs(diffMinutes) < 1) return "just now";
  if (Math.abs(diffMinutes) < 60) return `${diffMinutes}m ago`;
  const diffHours = Math.round(diffMinutes / 60);
  if (Math.abs(diffHours) < 48) return `${diffHours}h ago`;
  return `${Math.round(diffHours / 24)}d ago`;
};

const getTraceTone = (trace: {
  status: "ok" | "error" | "unset";
  mast_failures: Array<{ severity: "benign" | "fatal"; mode: string }>;
}) => {
  const fatalFailures = trace.mast_failures.filter((failure) => failure.severity === "fatal").length;

  if (trace.status === "error" || fatalFailures > 0) {
    return {
      label: "Critical incident",
      labelClass: "border-destructive/30 bg-destructive/12 text-destructive",
      cardClass:
        "border-destructive/25 bg-[radial-gradient(circle_at_top_left,hsl(var(--destructive))/0.1,transparent_30%),hsl(var(--card))]",
    };
  }

  if (trace.mast_failures.length > 0) {
    return {
      label: "Watch closely",
      labelClass: "border-amber-500/30 bg-amber-500/12 text-amber-700 dark:text-amber-300",
      cardClass:
        "border-amber-500/25 bg-[radial-gradient(circle_at_top_left,hsl(var(--chart-4))/0.1,transparent_30%),hsl(var(--card))]",
    };
  }

  return {
    label: "Healthy baseline",
    labelClass: "border-emerald-500/25 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300",
    cardClass:
      "border-emerald-500/20 bg-[radial-gradient(circle_at_top_left,hsl(var(--chart-2))/0.1,transparent_30%),hsl(var(--card))]",
  };
};

export default async function WorkspacePage() {
  await requireCloudProject("/workspace");
  const [usageSummary, traceData, insightSummary, baselineResponse] = await Promise.all([
    getProjectUsageSummary(),
    getTraces(),
    getProjectInsights(),
    getProjectBaseline(),
  ]).catch(() => redirectToBootstrap("/workspace"));
  const traces = traceData.traces;
  const topInsights = insightSummary.insights.slice(0, 3);
  const latestFailingTrace =
    traces.find((trace) => trace.status === "error" || trace.mast_failures.length > 0) ??
    traces[0] ??
    null;
  const recentHealthyTrace = traces.find((trace) => trace.status === "ok") ?? null;
  const usagePercentage = Math.round(usageSummary.usage.usage_ratio * 100);
  const nextTraceTone = latestFailingTrace ? getTraceTone(latestFailingTrace) : null;
  const healthyTraceTone = recentHealthyTrace ? getTraceTone(recentHealthyTrace) : null;
  const baseline = baselineResponse.baseline;
  const latestFailingComparison =
    latestFailingTrace && baseline && baseline.trace_id !== latestFailingTrace.trace_id
      ? (await getTraceComparison(latestFailingTrace.trace_id)).comparison
      : null;

  return (
    <div className="space-y-8 px-6 py-8 lg:px-8">
      <section className="section-fade overflow-hidden rounded-[2rem] border bg-[radial-gradient(circle_at_top_left,hsl(var(--destructive))/0.14,transparent_28%),radial-gradient(circle_at_top_right,hsl(var(--chart-1))/0.14,transparent_30%),hsl(var(--card))] p-8 shadow-sm">
        <div className="grid gap-8 xl:grid-cols-[1.2fr_0.8fr]">
          <div className="space-y-5">
            <Badge variant="outline">Mission control</Badge>
            <div className="space-y-4">
              <h1 className="max-w-4xl text-4xl font-semibold tracking-tight lg:text-6xl">
                See which run needs you next.
              </h1>
              <p className="max-w-2xl text-lg text-muted-foreground">
                Rifft is strongest when it helps you move from “something broke” to the exact
                trace, handoff, and root cause worth opening first.
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              <Button asChild>
                <Link href="/traces">
                  Open incident queue
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button asChild variant="outline">
                <Link href="/settings">Review plan and usage</Link>
              </Button>
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-1">
            <div
              className={`rounded-2xl border p-4 backdrop-blur ${
                nextTraceTone?.cardClass ?? "border-destructive/30 bg-background/65"
              }`}
            >
              <div className="flex items-center gap-2 text-sm font-medium text-destructive">
                <AlertTriangle className="h-4 w-4" />
                Next incident
              </div>
              {latestFailingTrace ? (
                <>
                  <div className="mt-3 font-mono text-sm">
                    {latestFailingTrace.trace_id.slice(0, 18)}...
                  </div>
                  <div className="mt-2 flex flex-wrap gap-2">
                    <span
                      className={`inline-flex items-center rounded-full border px-2.5 py-1 text-[10px] font-medium uppercase tracking-[0.12em] ${nextTraceTone?.labelClass}`}
                    >
                      {nextTraceTone?.label}
                    </span>
                    <Badge variant="outline">{formatRelative(latestFailingTrace.started_at)}</Badge>
                  </div>
                  <div className="mt-2 text-xs text-muted-foreground">
                    {latestFailingTrace.mast_failures[0]?.mode ?? latestFailingTrace.status}
                  </div>
                </>
              ) : (
                <div className="mt-3 text-sm text-muted-foreground">No active incidents yet.</div>
              )}
            </div>
            <div className="rounded-2xl border bg-background/65 p-4 backdrop-blur">
              <div className="flex items-center gap-2 text-sm font-medium">
                <CreditCard className="h-4 w-4" />
                Plan and usage
              </div>
              <div className="mt-3 text-2xl font-semibold">{usageSummary.plan.name}</div>
              <div className="mt-2 text-xs text-muted-foreground">
                {formatSpanCount(usageSummary.usage.used_spans)} of{" "}
                {formatSpanCount(usageSummary.usage.included_spans)} spans this month
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="stagger-1 section-fade grid gap-4 xl:grid-cols-3">
        <Card className="surface-lift rounded-3xl shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <AlertTriangle className="h-5 w-5 text-destructive" />
              Open first
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {latestFailingTrace ? (
              <>
                <div
                  className={`rounded-2xl border p-4 ${nextTraceTone?.cardClass ?? "border-destructive/20 bg-destructive/5"}`}
                >
                  <div className="font-mono text-sm">{latestFailingTrace.trace_id}</div>
                  <div className="mt-2 flex flex-wrap gap-2">
                    <Badge variant="destructive">{latestFailingTrace.status}</Badge>
                    <span
                      className={`inline-flex items-center rounded-full border px-2.5 py-1 text-[10px] font-medium uppercase tracking-[0.12em] ${nextTraceTone?.labelClass}`}
                    >
                      {nextTraceTone?.label}
                    </span>
                    <Badge variant="outline">{latestFailingTrace.agent_count} agents</Badge>
                    <Badge variant="outline">{latestFailingTrace.mast_failures.length} failures</Badge>
                  </div>
                </div>
                <Button asChild className="w-full">
                  <Link href={`/traces/${latestFailingTrace.trace_id}`}>
                    Open incident trace
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                </Button>
              </>
            ) : (
              <p className="text-sm text-muted-foreground">
                No failing traces yet. Your next trace will show up here.
              </p>
            )}
          </CardContent>
        </Card>

        <Card className="surface-lift rounded-3xl shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <TimerReset className="h-5 w-5" />
              Monthly usage
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-end justify-between gap-3">
              <div>
                <div className="text-3xl font-semibold">{usagePercentage}%</div>
                <div className="text-sm text-muted-foreground">of included usage consumed</div>
              </div>
              <Badge variant={usageSummary.plan.key === "pro" ? "default" : "outline"}>
                {usageSummary.plan.key === "pro" ? "Paid" : "Free"}
              </Badge>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-muted">
              <div
                className="h-full rounded-full bg-primary"
                style={{ width: `${Math.min(usagePercentage, 100)}%` }}
              />
            </div>
            <div className="text-sm text-muted-foreground">
              {formatSpanCount(usageSummary.usage.used_spans)} of{" "}
              {formatSpanCount(usageSummary.usage.included_spans)} spans
            </div>
          </CardContent>
        </Card>

        <Card className="surface-lift rounded-3xl shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <CheckCircle2 className="h-5 w-5 text-emerald-500" />
              Most recent healthy run
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {recentHealthyTrace ? (
              <>
                <div
                  className={`rounded-2xl border p-4 ${healthyTraceTone?.cardClass ?? "bg-muted/20"}`}
                >
                  <div className="font-mono text-sm">
                    {recentHealthyTrace.trace_id.slice(0, 18)}...
                  </div>
                  <div className="mt-2">
                    <span
                      className={`inline-flex items-center rounded-full border px-2.5 py-1 text-[10px] font-medium uppercase tracking-[0.12em] ${healthyTraceTone?.labelClass}`}
                    >
                      {healthyTraceTone?.label}
                    </span>
                  </div>
                  <div className="mt-2 text-sm text-muted-foreground">
                    {recentHealthyTrace.agent_count} agents •{" "}
                    {formatRelative(recentHealthyTrace.started_at)}
                  </div>
                </div>
                <Button asChild variant="outline" className="w-full">
                  <Link href={`/traces/${recentHealthyTrace.trace_id}`}>Open healthy baseline</Link>
                </Button>
              </>
            ) : (
              <p className="text-sm text-muted-foreground">
                No successful traces yet. Once one lands, use it as your baseline.
              </p>
            )}
          </CardContent>
        </Card>
      </section>

      <section className="stagger-1 section-fade">
        <Card className="surface-lift rounded-3xl shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Flag className="h-5 w-5" />
              Before / after baseline
            </CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 xl:grid-cols-[0.8fr_1.2fr]">
            <div className="rounded-2xl border bg-muted/20 p-4">
              {baseline ? (
                <div className="space-y-3">
                  <div className="text-xs font-medium uppercase tracking-[0.14em] text-muted-foreground">
                    Current baseline
                  </div>
                  <div className="font-mono text-sm">{baseline.trace_id}</div>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant={baseline.trace_status === "error" ? "destructive" : "secondary"}>
                      {baseline.trace_status ?? "unknown"}
                    </Badge>
                    {baseline.trace_started_at ? (
                      <Badge variant="outline">{formatRelative(baseline.trace_started_at)}</Badge>
                    ) : null}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Mark a healthy or representative trace as your baseline, then compare newer runs
                    against it to see whether the fix actually helped.
                  </p>
                  <Button asChild variant="outline" className="w-full">
                    <Link href={`/traces/${baseline.trace_id}`}>Open baseline trace</Link>
                  </Button>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="text-sm text-muted-foreground">
                    You have not marked a baseline yet. Pick a healthy or representative trace and
                    save it as the baseline so Rifft can show before/after deltas.
                  </div>
                  <Button asChild variant="outline" className="w-full">
                    <Link href={recentHealthyTrace ? `/traces/${recentHealthyTrace.trace_id}` : "/traces"}>
                      {recentHealthyTrace ? "Open healthy trace to baseline" : "Open traces"}
                    </Link>
                  </Button>
                </div>
              )}
            </div>

            <div className="rounded-2xl border bg-background p-4">
              {latestFailingComparison && latestFailingTrace ? (
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge
                      variant={
                        latestFailingComparison.verdict === "improved"
                          ? "secondary"
                          : latestFailingComparison.verdict === "regressed"
                            ? "destructive"
                            : "outline"
                      }
                    >
                      {latestFailingComparison.verdict === "improved"
                        ? "Improved vs baseline"
                        : latestFailingComparison.verdict === "regressed"
                          ? "Regressed vs baseline"
                          : latestFailingComparison.verdict === "same"
                            ? "Same as baseline"
                            : "Changed vs baseline"}
                    </Badge>
                    <Badge variant="outline">Latest incident</Badge>
                  </div>
                  <div className="grid gap-3 md:grid-cols-3">
                    <div className="rounded-2xl border bg-muted/20 p-4">
                      <div className="flex items-center gap-2 text-sm font-medium">
                        {latestFailingComparison.deltas.failure_count <= 0 ? (
                          <TrendingDown className="h-4 w-4 text-emerald-500" />
                        ) : (
                          <TrendingUp className="h-4 w-4 text-destructive" />
                        )}
                        Failure delta
                      </div>
                      <div className="mt-2 text-2xl font-semibold">
                        {formatSignedValue(latestFailingComparison.deltas.failure_count)}
                      </div>
                      <div className="mt-1 text-xs text-muted-foreground">
                        Fatal {formatSignedValue(latestFailingComparison.deltas.fatal_failure_count)}
                      </div>
                    </div>
                    <div className="rounded-2xl border bg-muted/20 p-4">
                      <div className="text-sm font-medium">New vs resolved</div>
                      <div className="mt-2 text-sm text-muted-foreground">
                        {latestFailingComparison.failure_modes.new_modes.length} new modes •{" "}
                        {latestFailingComparison.failure_modes.resolved_modes.length} resolved
                      </div>
                      <div className="mt-2 flex flex-wrap gap-2">
                        {latestFailingComparison.failure_modes.new_modes.slice(0, 2).map((mode) => (
                          <Badge key={mode} variant="destructive">
                            {mode}
                          </Badge>
                        ))}
                        {latestFailingComparison.failure_modes.resolved_modes.slice(0, 1).map((mode) => (
                          <Badge key={mode} variant="secondary">
                            Resolved: {mode}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="rounded-2xl border bg-muted/20 p-4">
                      <div className="text-sm font-medium">Root cause shift</div>
                      <div className="mt-2 text-sm text-muted-foreground">
                        {latestFailingComparison.root_cause.baseline ?? "Not inferred"} →{" "}
                        <span className="font-medium text-foreground">
                          {latestFailingComparison.root_cause.current ?? "Not inferred"}
                        </span>
                      </div>
                      <div className="mt-1 text-xs text-muted-foreground">
                        {latestFailingComparison.status_transition.baseline} →{" "}
                        {latestFailingComparison.status_transition.current}
                      </div>
                    </div>
                  </div>
                  <Button asChild className="w-full md:w-auto">
                    <Link href={`/traces/${latestFailingTrace.trace_id}`}>
                      Open compared incident
                      <ArrowRight className="h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="text-sm text-muted-foreground">
                    Once you have both a baseline and a newer incident, Rifft will show whether the
                    latest change improved failure rate, shifted the root cause, or introduced new
                    failure modes.
                  </div>
                  <Button asChild variant="outline">
                    <Link href="/traces">Go to incident queue</Link>
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </section>

      <section className="stagger-2 section-fade space-y-4">
        <div className="flex flex-col gap-2 lg:flex-row lg:items-end lg:justify-between">
          <div className="space-y-2">
            <Badge variant="outline">What should I fix first?</Badge>
            <h2 className="text-2xl font-semibold tracking-tight lg:text-3xl">
              Recurring failure patterns across recent traces
            </h2>
            <p className="max-w-3xl text-sm text-muted-foreground">
              Rifft is starting to connect failures across runs, so you can see what keeps
              breaking instead of opening every trace cold.
            </p>
          </div>
          <div className="text-sm text-muted-foreground">
            Looking across the last {insightSummary.recent_trace_window} trace
            {insightSummary.recent_trace_window === 1 ? "" : "s"}
          </div>
        </div>

        {topInsights.length > 0 ? (
          <div className="grid gap-4 xl:grid-cols-3">
            {topInsights.map((insight, index) => {
              const meta = getMastMeta(insight.mode);
              const tokenPressure = insight.token_pressure;
              const nearLimitRatio = tokenPressure?.near_limit_ratio ?? null;
              const hasTokenPressure =
                tokenPressure?.median_input_tokens !== null &&
                tokenPressure?.median_context_limit !== null;

              return (
                <Card
                  key={insight.mode}
                  className={`surface-lift rounded-3xl shadow-sm ${
                    index === 0
                      ? "border-destructive/25 bg-[radial-gradient(circle_at_top_left,hsl(var(--destructive))/0.12,transparent_34%),hsl(var(--card))]"
                      : ""
                  }`}
                >
                  <CardHeader className="space-y-4">
                    <div className="flex flex-wrap items-center gap-2">
                      {index === 0 ? <Badge variant="destructive">Fix this first</Badge> : null}
                      <Badge variant={insight.severity === "fatal" ? "destructive" : "outline"}>
                        {insight.severity === "fatal" ? "Fatal pattern" : "Recurring pattern"}
                      </Badge>
                    </div>
                    <div className="space-y-2">
                      <CardTitle className="text-xl">{meta.label}</CardTitle>
                      <p className="text-sm text-muted-foreground">
                        Seen in {insight.affected_trace_count} of the last{" "}
                        {insight.recent_trace_window} traces ({formatPercentage(insight.share_of_recent_traces)}).
                      </p>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="rounded-2xl border bg-muted/20 p-4">
                      <div className="text-xs font-medium uppercase tracking-[0.14em] text-muted-foreground">
                        Why this keeps showing up
                      </div>
                      <p className="mt-2 text-sm text-muted-foreground">
                        {insight.dominant_agent_id
                          ? `${meta.explanation} The pattern clusters most often around ${insight.dominant_agent_id}.`
                          : meta.explanation}
                      </p>
                    </div>

                    {hasTokenPressure ? (
                      <div className="rounded-2xl border border-amber-500/25 bg-amber-500/8 p-4 text-sm">
                        <div className="font-medium text-amber-700 dark:text-amber-300">
                          Token pressure is a likely contributor
                        </div>
                        <p className="mt-2 text-muted-foreground">
                          When this failure appears, the median input is about{" "}
                          {formatTokenCount(tokenPressure?.median_input_tokens ?? 0)} tokens against a
                          median context limit of{" "}
                          {formatTokenCount(tokenPressure?.median_context_limit ?? 0)}.
                          {nearLimitRatio !== null
                            ? ` ${formatPercentage(nearLimitRatio)} of the sampled runs were already within 15% of their context window.`
                            : ""}
                        </p>
                      </div>
                    ) : (
                      <div className="rounded-2xl border bg-muted/20 p-4">
                        <div className="text-xs font-medium uppercase tracking-[0.14em] text-muted-foreground">
                          Most common trigger
                        </div>
                        <p className="mt-2 text-sm text-muted-foreground">
                          {insight.sample_explanation}
                        </p>
                      </div>
                    )}

                    <div className="rounded-2xl border bg-background p-4">
                      <div className="text-xs font-medium uppercase tracking-[0.14em] text-muted-foreground">
                        Recommended next fix
                      </div>
                      <p className="mt-2 text-sm text-muted-foreground">{meta.recommendedFix}</p>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-muted-foreground">
                      <div>
                        {insight.occurrence_count} total signal{insight.occurrence_count === 1 ? "" : "s"}
                        {insight.dominant_agent_id && insight.dominant_agent_share !== null
                          ? ` • ${formatPercentage(insight.dominant_agent_share)} on ${insight.dominant_agent_id}`
                          : ""}
                      </div>
                      {insight.latest_started_at ? <div>Latest {formatRelative(insight.latest_started_at)}</div> : null}
                    </div>

                    {insight.latest_trace_id ? (
                      <Button asChild className="w-full justify-between">
                        <Link href={`/traces/${insight.latest_trace_id}`}>
                          Open latest example
                          <ArrowRight className="h-4 w-4" />
                        </Link>
                      </Button>
                    ) : null}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <Card className="surface-lift rounded-3xl shadow-sm">
            <CardContent className="flex flex-col gap-3 p-6 text-sm text-muted-foreground lg:flex-row lg:items-center lg:justify-between">
              <div>
                Once your project has a few traces with MAST signals, Rifft will start grouping the
                patterns that repeat across runs and call out the one worth fixing first.
              </div>
              <Button asChild variant="outline">
                <Link href="/onboarding">Send another trace</Link>
              </Button>
            </CardContent>
          </Card>
        )}
      </section>

      <section className="stagger-2 section-fade grid gap-4 xl:grid-cols-3">
        <Card className="surface-lift rounded-3xl shadow-sm xl:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Workflow className="h-5 w-5" />
              Recent trace activity
            </CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3">
            {traces.slice(0, 5).map((trace) => (
              <Link
                key={trace.trace_id}
                href={`/traces/${trace.trace_id}`}
                className={`surface-lift flex flex-col gap-3 rounded-2xl border p-4 transition-colors hover:bg-muted/30 lg:flex-row lg:items-center lg:justify-between ${getTraceTone(trace).cardClass}`}
              >
                <div className="space-y-2">
                  <div className="font-mono text-sm">{trace.trace_id}</div>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant={trace.status === "error" ? "destructive" : "secondary"}>
                      {trace.status}
                    </Badge>
                    <span
                      className={`inline-flex items-center rounded-full border px-2.5 py-1 text-[10px] font-medium uppercase tracking-[0.12em] ${getTraceTone(trace).labelClass}`}
                    >
                      {getTraceTone(trace).label}
                    </span>
                    {trace.mast_failures.slice(0, 2).map((failure) => (
                      <Badge
                        key={`${trace.trace_id}-${failure.mode}`}
                        variant={failure.severity === "fatal" ? "destructive" : "outline"}
                      >
                        {failure.mode}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="text-sm text-muted-foreground">
                  {trace.agent_count} agents • {formatRelative(trace.started_at)}
                </div>
              </Link>
            ))}
          </CardContent>
        </Card>

        <Card className="surface-lift rounded-3xl shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Sparkles className="h-5 w-5" />
              What to do next
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm text-muted-foreground">
            {topInsights[0] ? (
              <>
                <p>
                  The strongest recurring signal right now is{" "}
                  <span className="font-medium text-foreground">
                    {getMastMeta(topInsights[0].mode).label.toLowerCase()}
                  </span>
                  . That pattern shows up in {topInsights[0].affected_trace_count} of your last{" "}
                  {topInsights[0].recent_trace_window} traces.
                </p>
                <p>
                  Start with the latest example, confirm the failure path in the graph, and then
                  apply the recommended fix across the agent or prompt path that repeats.
                </p>
                {topInsights[0].latest_trace_id ? (
                  <Button asChild variant="outline" className="w-full">
                    <Link href={`/traces/${topInsights[0].latest_trace_id}`}>Open latest example</Link>
                  </Button>
                ) : null}
              </>
            ) : (
              <>
                <p>
                  Start from the failing run, then move straight into the graph, the handoff that
                  mattered, and the replay path.
                </p>
                <p>
                  The product should tell you what to open next, not make you hunt through generic
                  dashboards.
                </p>
                <Button asChild variant="outline" className="w-full">
                  <Link href="/traces">Go to incident queue</Link>
                </Button>
              </>
            )}
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
