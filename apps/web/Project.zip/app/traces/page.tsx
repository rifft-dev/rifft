import { Badge } from "@/components/ui/badge";
import { getTraces } from "../lib/api";
import { redirectToBootstrap, requireCloudProject } from "../lib/require-cloud-project";
import { TraceListClient } from "./trace-list-client";

export default async function TracesPage() {
  await requireCloudProject("/traces");
  const data = await getTraces().catch(() => redirectToBootstrap("/traces"));
  const failingCount = data.traces.filter((trace) => trace.status === "error" || trace.mast_failures.length > 0).length;

  return (
    <div className="space-y-6 px-6 py-8 lg:px-8">
      <section className="rounded-[2rem] border bg-[radial-gradient(circle_at_top_left,hsl(var(--destructive))/0.1,transparent_26%),radial-gradient(circle_at_top_right,hsl(var(--chart-1))/0.12,transparent_30%),hsl(var(--card))] p-8 shadow-sm">
        <Badge variant="outline">Incident queue</Badge>
        <h1 className="mt-4 text-4xl font-semibold tracking-tight">Open the run that matters first</h1>
        <p className="mt-3 max-w-2xl text-muted-foreground">
          Rifft surfaces the traces most likely to explain the failure you care about now, then lets
          you drop straight into the graph, handoff, and replay path.
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          <Badge variant={failingCount > 0 ? "destructive" : "secondary"}>
            {failingCount} needing attention
          </Badge>
          <Badge variant="outline">{data.total} total traces</Badge>
        </div>
      </section>
      <TraceListClient traces={data.traces} />
    </div>
  );
}
